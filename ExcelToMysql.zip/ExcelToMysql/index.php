<?php
if ( isset($_POST["submit"]) ) {
$storagename = $_FILES["file"]["name"];
$lokasi=$_FILES["file"]["tmp_name"];
$n=move_uploaded_file($_FILES["file"]["tmp_name"],$storagename);
if($n){
header("location:proses.inc.php?fn=$storagename");

}else{
header("location:index.php?msg=nosend");

}

}
?>
<!DOCTYPE html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <meta name="robots" content="noindex,nofollow">
    <title>Aplikasi Import</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
  <script src="js/jquery.js"></script>
    <!-- Custom CSS -->
    <link href="css/blog-home.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
  </head>

<body>
<div class="container">

        <div class="row">
            <div class="col-md-8">
          		<div class="col-lg-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                        <h3 class="panel-title"><i class="fa fa-user"></i>Aplikasi Import</h3> 
                        </div>
                        
                        <div class="panel-body">
                        <?php
                        error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
                         if($_GET['msg']=='send')
         {
//          jika impor berhasil
          echo '<div class="alert alert-warning alert-dismissable"id="alert">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;
          </button>1 Data berhasil di Update</div>';
    } else  if($_GET['msg']=='nosend')
         {
//          jika impor berhasil
          echo '<div class="alert alert-danger alert-dismissable"id="alert">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;
          </button>Gagal upload File !</div>';
    }
       else  if($_GET['msg']=='')
         {
//          jika impor berhasil
          echo '<div class="alert alert-info alert-dismissable"id="alert">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;
          </button>file XLS (Excel 2003) yang diijinkan !</div>';
    }
    ?>

<form action="<?php echo $_SERVER["PHP_SELF"]; ?>" onSubmit="return validateForm()" method="post" enctype="multipart/form-data">
<input type="file" class="form-control" name="file" id="file" /><br />
<button type="submit"name="submit" class="btn btn-primary">Upload</button>
</form>
<script type="text/javascript">
//    validasi form (hanya file .xls yang diijinkan)
    function validateForm()
    {
        function hasExtension(inputID, exts) {
            var fileName = document.getElementById(inputID).value;
            return (new RegExp('(' + exts.join('|').replace(/\./g, '\\.') + ')$')).test(fileName);
        }
 
        if(!hasExtension('file', ['.xls'])){
            alert("Hanya file XLS (Excel 2003) yang diijinkan.");
            return false;
        }
    }
</script>





<script type="text/javascript">

$(document).ready(function () {
 
window.setTimeout(function() {
    $(".alert").fadeTo(1000, 0).slideUp(1000, function(){
        $(this).remove(); 
    });
}, 3000);
 
});
</script>
          
              </div> 
              </div>
            
            </div><!-- col-lg-12-->      	
          	</div><!-- /row -->

      <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

  </body>
</html>