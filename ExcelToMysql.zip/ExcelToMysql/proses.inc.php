<?php
 error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
define ("DB_HOST", "localhost"); // set database host
define ("DB_USER", "root"); // set database user
define ("DB_PASS",""); // set database password
define ("DB_NAME","siswa"); // set database name

@mysql_connect(DB_HOST, DB_USER, DB_PASS) or die("Couldn't make connection.");
@mysql_select_db(DB_NAME) or die("Couldn't select database");

$databasetable = "nilai";

/************************ YOUR DATABASE CONNECTION END HERE  ****************************/


set_include_path(get_include_path() . PATH_SEPARATOR . 'Classes/');
include 'PHPExcel/IOFactory.php';


// This is the file path to be uploaded.
$inputFileName = $_GET['fn']; 
try {
	$objPHPExcel = PHPExcel_IOFactory::load($inputFileName);
} catch(Exception $e) {
	die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
}


$allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
$arrayCount = count($allDataInSheet);  // Here get total count of row in that Excel sheet


for($i=2;$i<=$arrayCount;$i++){
$a = trim($allDataInSheet[$i]["A"]);
$b = trim($allDataInSheet[$i]["B"]);
$c = trim($allDataInSheet[$i]["C"]);
$d = trim($allDataInSheet[$i]["D"]);
$e = trim($allDataInSheet[$i]["E"]);
$f = trim($allDataInSheet[$i]["F"]);

 $query = "INSERT into nilai(a,b,c,d,e,f)values
    ('$a','$b','$c','$d','$e','$f')";
      $hasils = mysql_query($query);
if ($hasils) {


@unlink ("$inputFileName");
header("location:index.php?msg=send");
}


}